public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Game game = new Game();

//		while(true) {
//			try {
//				Thread.sleep(1);
//			} catch (InterruptedException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//			if (!game.running) {
//				System.out.println("Test");
//			}
//		}
	}
}
